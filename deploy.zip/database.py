import sqlite3
from datetime import datetime, timedelta
import os

DATABASE_PATH = 'outage_map.db'

def init_database():
    """Initialize the database with required tables"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    # Create markers table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS markers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            latitude REAL NOT NULL,
            longitude REAL NOT NULL,
            marker_type TEXT NOT NULL CHECK (marker_type IN ('outage', 'working')),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP NOT NULL
        )
    ''')
    
    # Create index for faster queries
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_expires_at ON markers(expires_at)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_marker_type ON markers(marker_type)')
    
    conn.commit()
    conn.close()
    print("Database initialized successfully")

def cleanup_expired_markers():
    """Remove markers that have expired (older than 1 hour)"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    current_time = datetime.now()
    cursor.execute('DELETE FROM markers WHERE expires_at < ?', (current_time,))
    
    deleted_count = cursor.rowcount
    conn.commit()
    conn.close()
    
    if deleted_count > 0:
        print(f"Cleaned up {deleted_count} expired markers")
    
    return deleted_count

def add_marker(latitude, longitude, marker_type):
    """Add a new marker to the database"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    # Set expiration time to 1 hour from now
    created_at = datetime.now()
    expires_at = created_at + timedelta(hours=1)
    
    cursor.execute('''
        INSERT INTO markers (latitude, longitude, marker_type, created_at, expires_at)
        VALUES (?, ?, ?, ?, ?)
    ''', (latitude, longitude, marker_type, created_at, expires_at))
    
    marker_id = cursor.lastrowid
    conn.commit()
    conn.close()
    
    return marker_id

def get_active_markers():
    """Get all active (non-expired) markers"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    current_time = datetime.now()
    cursor.execute('''
        SELECT id, latitude, longitude, marker_type, created_at, expires_at
        FROM markers 
        WHERE expires_at > ?
        ORDER BY created_at DESC
    ''', (current_time,))
    
    markers = cursor.fetchall()
    conn.close()
    
    # Convert to list of dictionaries
    marker_list = []
    for marker in markers:
        marker_list.append({
            'id': marker[0],
            'latitude': marker[1],
            'longitude': marker[2],
            'type': marker[3],
            'created_at': marker[4],
            'expires_at': marker[5]
        })
    
    return marker_list

def check_marker_collision(latitude, longitude, marker_type, radius_meters=40):
    """Check if a marker can be placed at the given location (collision detection)"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    current_time = datetime.now()
    
    # Get all active markers
    cursor.execute('''
        SELECT latitude, longitude FROM markers 
        WHERE expires_at > ? AND marker_type = ?
    ''', (current_time, marker_type))
    
    existing_markers = cursor.fetchall()
    conn.close()
    
    # Check distance using approximate calculation
    # 1 degree latitude ≈ 111 km, 1 degree longitude ≈ 111 km * cos(latitude)
    import math
    
    for existing_lat, existing_lng in existing_markers:
        # Simple distance calculation (good enough for small distances)
        lat_diff = abs(latitude - existing_lat)
        lng_diff = abs(longitude - existing_lng)
        
        # Convert to meters (approximate)
        lat_meters = lat_diff * 111000
        lng_meters = lng_diff * 111000 * math.cos(math.radians(latitude))
        
        distance = math.sqrt(lat_meters**2 + lng_meters**2)
        
        if distance < radius_meters:
            return False  # Collision detected
    
    return True  # No collision

if __name__ == '__main__':
    init_database()
