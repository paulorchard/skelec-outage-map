from flask import Flask, render_template, jsonify, request
import os
from datetime import datetime
from database import init_database, add_marker, get_active_markers, cleanup_expired_markers, check_marker_collision
import threading
import time

app = Flask(__name__)

# Configuration
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
app.config['DEBUG'] = os.environ.get('FLASK_DEBUG', 'True').lower() == 'true'

# Initialize database
init_database()

# Background cleanup thread function
def cleanup_thread():
    """Background thread to periodically clean up expired markers"""
    while True:
        time.sleep(300)  # Run every 5 minutes
        cleanup_expired_markers()

# Start cleanup thread
cleanup_worker = threading.Thread(target=cleanup_thread, daemon=True)
cleanup_worker.start()

# Saint Kitts coordinates - Fort Street & Cayon Street intersection, Basseterre
SAINT_KITTS_CENTER = {
    'lat': 17.29700198349977,
    'lng': -62.72387210886741,
    'zoom': 14
}

@app.route('/')
def index():
    """Main outage map page for Saint Kitts"""
    return render_template('index.html', 
                         title='St. Kitts Power Outages',
                         center_lat=SAINT_KITTS_CENTER['lat'],
                         center_lng=SAINT_KITTS_CENTER['lng'],
                         zoom=SAINT_KITTS_CENTER['zoom'])

@app.route('/api/outages')
def get_outages():
    """API endpoint to get current power outage data"""
    # No hardcoded outages - only user-generated markers from database will show
    sample_outages = []
    
    return jsonify({
        'outages': sample_outages,
        'last_updated': datetime.now().isoformat(),
        'total_outages': len(sample_outages)
    })

@app.route('/api/status')
def api_status():
    """API endpoint to check application status"""
    return jsonify({
        'status': 'running',
        'timestamp': datetime.now().isoformat(),
        'version': '1.0.0',
        'location': 'Saint Kitts and Nevis'
    })

@app.route('/api/markers', methods=['GET'])
def get_markers():
    """Get all active markers from database"""
    try:
        # Clean up expired markers first
        cleanup_expired_markers()
        
        # Get active markers
        markers = get_active_markers()
        
        return jsonify({
            'success': True,
            'markers': markers,
            'count': len(markers)
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/markers', methods=['POST'])
def add_new_marker():
    """Add a new marker to the database"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Validate required fields
        required_fields = ['latitude', 'longitude', 'type']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        latitude = float(data['latitude'])
        longitude = float(data['longitude'])
        marker_type = data['type']
        
        # Validate marker type
        if marker_type not in ['outage', 'working']:
            return jsonify({
                'success': False,
                'error': 'Invalid marker type. Must be "outage" or "working"'
            }), 400
        
        # Check for collisions
        if not check_marker_collision(latitude, longitude, marker_type):
            return jsonify({
                'success': False,
                'error': 'Another marker of the same type already exists within 40 meters'
            }), 409
        
        # Add marker to database
        marker_id = add_marker(latitude, longitude, marker_type)
        
        return jsonify({
            'success': True,
            'marker_id': marker_id,
            'message': f'{marker_type.title()} marker added successfully'
        }), 201
        
    except ValueError as e:
        return jsonify({
            'success': False,
            'error': 'Invalid latitude or longitude values'
        }), 400
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/health')
def health_check():
    """Health check endpoint for monitoring"""
    return jsonify({'status': 'healthy'})

if __name__ == '__main__':
    # Development server - accessible from network
    app.run(
        host=os.environ.get('HOST', '0.0.0.0'),  # Listen on all interfaces
        port=int(os.environ.get('PORT', 5000)),
        debug=app.config['DEBUG']
    )
